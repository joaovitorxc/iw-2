create database dogs;
use dogs;

create table race(
    id int auto_increment not null,
    dogsname varchar(50) null,
    dogscolor varchar(50) null;
    age int null,
    primary key(id)
);

select * from race;